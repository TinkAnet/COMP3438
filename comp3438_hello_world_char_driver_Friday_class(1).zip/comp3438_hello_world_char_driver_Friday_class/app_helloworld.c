#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void main() {
    int fd;
    int count;
    char buf[256];


    fd = open("/dev/helloworld_device_file_1", O_RDONLY);
    if (fd == -1) {
        printf("Fail to open device file.\n");
        return;
    }
    count = read(fd, buf, 100);
    buf[count] = 0;
    printf("User: %d bytes are read from the device file.\n", count);
    printf("User: the bytes are \"%s\".\n", buf);
    close(fd);
}

